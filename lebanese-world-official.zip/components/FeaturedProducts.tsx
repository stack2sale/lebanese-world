"use client"

import { useState } from "react"
import Image from "next/image"
import { ShoppingCart, Heart, Download, Star, Eye } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function FeaturedProducts() {
  const [activeTab, setActiveTab] = useState("digital")

  const tabs = [
    { id: "digital", name: "Digital Products", icon: Download },
    { id: "physical", name: "Physical Crafts", icon: ShoppingCart },
    { id: "experiences", name: "Experiences", icon: Eye },
  ]

  const products = {
    digital: [
      {
        id: 1,
        title: "Complete Lebanon Travel Guide",
        description: "Comprehensive halal travel guide with 200+ pages of insider tips",
        price: 29.99,
        originalPrice: 49.99,
        image: "/placeholder.svg?height=300&width=300",
        rating: 4.9,
        reviews: 234,
        category: "Travel Guide",
        isDigital: true,
        downloadCount: "2.5K+",
        tags: ["Halal", "Travel", "PDF"],
      },
      {
        id: 2,
        title: "Arabic Calligraphy Font Pack",
        description: "12 premium Arabic fonts inspired by Lebanese heritage",
        price: 19.99,
        originalPrice: 39.99,
        image: "/placeholder.svg?height=300&width=300",
        rating: 4.8,
        reviews: 156,
        category: "Design Assets",
        isDigital: true,
        downloadCount: "1.8K+",
        tags: ["Arabic", "Fonts", "Design"],
      },
      {
        id: 3,
        title: "Islamic Wallpaper Collection",
        description: "50 high-resolution Islamic art wallpapers for devices",
        price: 9.99,
        originalPrice: 19.99,
        image: "/placeholder.svg?height=300&width=300",
        rating: 4.7,
        reviews: 89,
        category: "Digital Art",
        isDigital: true,
        downloadCount: "3.2K+",
        tags: ["Islamic", "Wallpapers", "Art"],
      },
    ],
    physical: [
      {
        id: 4,
        title: "Handwoven Lebanese Keffiyeh",
        description: "Authentic keffiyeh handwoven by Lebanese artisans",
        price: 89.99,
        originalPrice: 129.99,
        image: "/placeholder.svg?height=300&width=300",
        rating: 4.9,
        reviews: 67,
        category: "Traditional Wear",
        isDigital: false,
        stock: "Limited Edition",
        tags: ["Handmade", "Traditional", "Authentic"],
      },
      {
        id: 5,
        title: "Lebanese Spice Collection",
        description: "Premium halal spice set with traditional Lebanese blends",
        price: 45.99,
        originalPrice: 65.99,
        image: "/placeholder.svg?height=300&width=300",
        rating: 4.8,
        reviews: 123,
        category: "Food & Spices",
        isDigital: false,
        stock: "In Stock",
        tags: ["Halal", "Spices", "Authentic"],
      },
      {
        id: 6,
        title: "Cedar Wood Prayer Beads",
        description: "Handcrafted tasbih made from Lebanese cedar wood",
        price: 34.99,
        originalPrice: 49.99,
        image: "/placeholder.svg?height=300&width=300",
        rating: 5.0,
        reviews: 45,
        category: "Religious Items",
        isDigital: false,
        stock: "Limited Stock",
        tags: ["Cedar", "Prayer", "Handcrafted"],
      },
    ],
    experiences: [
      {
        id: 7,
        title: "Virtual Cooking Class",
        description: "Learn to cook traditional Lebanese dishes with expert chefs",
        price: 39.99,
        originalPrice: 59.99,
        image: "/placeholder.svg?height=300&width=300",
        rating: 4.9,
        reviews: 178,
        category: "Online Class",
        isDigital: true,
        duration: "2 hours",
        tags: ["Cooking", "Live", "Interactive"],
      },
      {
        id: 8,
        title: "Arabic Language Mini-Course",
        description: "4-week intensive Lebanese Arabic conversation course",
        price: 79.99,
        originalPrice: 119.99,
        image: "/placeholder.svg?height=300&width=300",
        rating: 4.8,
        reviews: 92,
        category: "Language Learning",
        isDigital: true,
        duration: "4 weeks",
        tags: ["Arabic", "Language", "Course"],
      },
      {
        id: 9,
        title: "Cultural Heritage Workshop",
        description: "Interactive workshop on Lebanese traditions and customs",
        price: 24.99,
        originalPrice: 39.99,
        image: "/placeholder.svg?height=300&width=300",
        rating: 4.7,
        reviews: 56,
        category: "Workshop",
        isDigital: true,
        duration: "90 minutes",
        tags: ["Culture", "Heritage", "Workshop"],
      },
    ],
  }

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Featured Marketplace</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Discover authentic Lebanese products, digital treasures, and cultural experiences that bring the beauty of
            our heritage directly to you.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {tabs.map((tab) => {
            const IconComponent = tab.icon
            return (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? "default" : "outline"}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-3 rounded-full transition-all duration-300 ${
                  activeTab === tab.id ? "bg-gradient-to-r from-red-600 to-green-600 text-white" : "hover:bg-gray-50"
                }`}
              >
                <IconComponent className="w-4 h-4 mr-2" />
                {tab.name}
              </Button>
            )
          })}
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products[activeTab as keyof typeof products].map((product) => (
            <Card
              key={product.id}
              className="group overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="relative overflow-hidden">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.title}
                  width={300}
                  height={300}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />

                {/* Overlay with quick actions */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="flex space-x-3">
                    <Button size="sm" variant="secondary" className="rounded-full">
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="secondary" className="rounded-full">
                      <Heart className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Badges */}
                <div className="absolute top-4 left-4 flex flex-col gap-2">
                  <Badge className="bg-red-500 text-white">
                    {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                  </Badge>
                  {product.isDigital && <Badge className="bg-blue-500 text-white">Instant Download</Badge>}
                </div>

                {/* Rating */}
                <div className="absolute top-4 right-4 bg-white/90 rounded-full px-2 py-1">
                  <div className="flex items-center space-x-1">
                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    <span className="text-xs font-medium">{product.rating}</span>
                  </div>
                </div>
              </div>

              <CardContent className="p-6">
                <div className="mb-2">
                  <Badge variant="outline" className="text-xs">
                    {product.category}
                  </Badge>
                </div>

                <h3 className="font-playfair text-lg font-bold text-gray-900 mb-2 group-hover:text-red-600 transition-colors">
                  {product.title}
                </h3>

                <p className="text-gray-600 text-sm mb-4 leading-relaxed">{product.description}</p>

                {/* Product Stats */}
                <div className="flex items-center text-xs text-gray-500 mb-4">
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400 mr-1" />
                  <span>
                    {product.rating} ({product.reviews} reviews)
                  </span>
                  {product.downloadCount && (
                    <>
                      <span className="mx-2">•</span>
                      <span>{product.downloadCount} downloads</span>
                    </>
                  )}
                  {product.duration && (
                    <>
                      <span className="mx-2">•</span>
                      <span>{product.duration}</span>
                    </>
                  )}
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1 mb-4">
                  {product.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                {/* Price and CTA */}
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-2xl font-bold text-gray-900">${product.price}</span>
                    <span className="text-sm text-gray-500 line-through ml-2">${product.originalPrice}</span>
                  </div>
                  <Button
                    size="sm"
                    className="bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700"
                  >
                    <ShoppingCart className="w-4 h-4 mr-1" />
                    Add to Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <Button size="lg" variant="outline" className="px-8 py-4 text-lg mr-4">
            View All Products
          </Button>
          <Button size="lg" className="px-8 py-4 text-lg bg-gradient-to-r from-red-600 to-green-600">
            Start Selling
          </Button>
        </div>
      </div>
    </section>
  )
}
