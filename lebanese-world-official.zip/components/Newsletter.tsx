"use client"

import type React from "react"

import { useState } from "react"
import { Mail, Gift, Check, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"

export default function Newsletter() {
  const [email, setEmail] = useState("")
  const [isSubscribed, setIsSubscribed] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setIsSubscribed(true)
    setIsLoading(false)
    setEmail("")
  }

  const benefits = [
    "Weekly cultural stories and heritage insights",
    "Exclusive discounts on marketplace products",
    "Early access to new tours and experiences",
    "Free Lebanon travel guide (PDF download)",
    "Islamic calendar events and celebrations",
    "Lebanese diaspora community updates",
  ]

  if (isSubscribed) {
    return (
      <section className="py-20 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="w-8 h-8 text-white" />
            </div>
            <h2 className="font-playfair text-3xl font-bold text-gray-900 mb-4">
              Welcome to the Lebanese World Family!
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Thank you for subscribing! Check your email for your free Lebanon travel guide and get ready to discover
              amazing cultural content.
            </p>
            <Button className="bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700">
              Explore Our Content
            </Button>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-20 bg-gradient-to-br from-red-50 to-green-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <div className="flex items-center mb-6">
              <div className="bg-gradient-to-r from-red-600 to-green-600 rounded-full p-3 mr-4">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <h2 className="font-playfair text-4xl font-bold text-gray-900">Join Our Community</h2>
            </div>

            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Get exclusive access to Lebanese cultural content, Islamic insights, and special offers delivered to your
              inbox every week.
            </p>

            {/* Free Gift Highlight */}
            <Card className="mb-8 border-2 border-green-200 bg-green-50">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Gift className="w-6 h-6 text-green-600 mr-3" />
                  <h3 className="font-semibold text-lg text-gray-900">Free Welcome Gift</h3>
                </div>
                <p className="text-gray-700">
                  Subscribe now and instantly receive our comprehensive
                  <strong> "Lebanon Starter Guide"</strong> - a 50-page PDF with travel tips, cultural insights, and
                  halal-friendly recommendations.
                </p>
              </CardContent>
            </Card>

            {/* Benefits List */}
            <div className="space-y-3">
              <h3 className="font-semibold text-lg text-gray-900 mb-4">What you'll receive:</h3>
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center">
                  <Check className="w-5 h-5 text-green-600 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Content - Newsletter Form */}
          <div>
            <Card className="shadow-xl">
              <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address
                    </label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email address"
                      required
                      className="w-full px-4 py-3 text-lg"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700 py-3 text-lg font-semibold"
                  >
                    {isLoading ? (
                      "Subscribing..."
                    ) : (
                      <>
                        Get My Free Guide
                        <ArrowRight className="ml-2 w-5 h-5" />
                      </>
                    )}
                  </Button>

                  <p className="text-xs text-gray-500 text-center">
                    By subscribing, you agree to our privacy policy. Unsubscribe at any time. We respect your privacy
                    and Islamic values.
                  </p>
                </form>

                {/* Social Proof */}
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <div className="text-center">
                    <p className="text-sm text-gray-600 mb-2">Trusted by Lebanese worldwide</p>
                    <div className="flex justify-center items-center space-x-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-gray-900">50K+</div>
                        <div className="text-xs text-gray-500">Subscribers</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-gray-900">25+</div>
                        <div className="text-xs text-gray-500">Countries</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-gray-900">4.9★</div>
                        <div className="text-xs text-gray-500">Rating</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
