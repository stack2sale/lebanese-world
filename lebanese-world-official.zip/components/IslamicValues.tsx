"use client"

import { useState } from "react"
import Image from "next/image"
import { Heart, Users, Scale, Globe } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function IslamicValues() {
  const [activeValue, setActiveValue] = useState(0)

  const values = [
    {
      icon: Heart,
      title: "Compassion & Love",
      arabic: "الرحمة والمحبة",
      description:
        "Islam teaches us to show mercy and love to all creation. In Lebanese culture, this manifests through our legendary hospitality and care for family and community.",
      quote:
        '"And We made from them leaders guiding by Our command when they were patient and were certain of Our signs." - Quran 32:24',
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      icon: Users,
      title: "Unity & Brotherhood",
      arabic: "الوحدة والأخوة",
      description:
        "The Lebanese diaspora exemplifies Islamic brotherhood, supporting each other across continents while maintaining strong bonds to our homeland.",
      quote:
        '"The believers in their mutual kindness, compassion, and sympathy are just one body." - Prophet Muhammad (PBUH)',
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      icon: Scale,
      title: "Justice & Equality",
      arabic: "العدالة والمساواة",
      description:
        "Islam champions justice and equality for all. Lebanese women have always been respected leaders, scholars, and pillars of our communities.",
      quote: '"O you who believe! Stand out firmly for justice, as witnesses to Allah." - Quran 4:135',
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      icon: Globe,
      title: "Global Community",
      arabic: "الأمة العالمية",
      description:
        "Lebanese Muslims worldwide form a global ummah, preserving our traditions while contributing positively to societies everywhere.",
      quote: '"And thus we have made you a just community that you will be witnesses over the people." - Quran 2:143',
      image: "/placeholder.svg?height=400&width=600",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Islamic Values in Lebanese Culture
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Discover how Islamic principles of peace, justice, and compassion are woven into the fabric of Lebanese
            heritage, creating a culture that honors both tradition and progress.
          </p>
        </div>

        {/* Values Grid */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Values List */}
          <div className="space-y-6">
            {values.map((value, index) => {
              const IconComponent = value.icon
              return (
                <Card
                  key={index}
                  className={`cursor-pointer transition-all duration-300 hover:shadow-lg ${
                    activeValue === index ? "ring-2 ring-red-500 shadow-lg" : ""
                  }`}
                  onClick={() => setActiveValue(index)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div
                        className={`p-3 rounded-lg ${
                          activeValue === index
                            ? "bg-gradient-to-br from-red-500 to-green-500 text-white"
                            : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        <IconComponent className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg text-gray-900 mb-1">{value.title}</h3>
                        <p className="text-sm text-gray-500 font-amiri mb-2">{value.arabic}</p>
                        <p className="text-gray-600 text-sm leading-relaxed">{value.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Active Value Display */}
          <div className="lg:sticky lg:top-24">
            <Card className="overflow-hidden shadow-xl">
              <div className="relative h-64">
                <Image
                  src={values[activeValue].image || "/placeholder.svg"}
                  alt={values[activeValue].title}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="font-playfair text-2xl font-bold text-white mb-2">{values[activeValue].title}</h3>
                  <p className="text-white/90 font-amiri text-lg">{values[activeValue].arabic}</p>
                </div>
              </div>
              <CardContent className="p-6">
                <blockquote className="text-gray-700 italic leading-relaxed border-l-4 border-red-500 pl-4">
                  {values[activeValue].quote}
                </blockquote>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Women in Islam Section */}
        <div className="bg-white rounded-2xl p-8 lg:p-12 shadow-lg">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="font-playfair text-3xl font-bold text-gray-900 mb-6">
                Women in Islam: Respect, Honor, and Leadership
              </h3>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  Islam elevated the status of women 1400 years ago, granting them rights that were revolutionary for
                  their time. Lebanese Muslim women embody this legacy as leaders, scholars, entrepreneurs, and
                  community builders.
                </p>
                <p>
                  From Khadijah (RA), the Prophet's first wife and successful businesswoman, to modern Lebanese women
                  leading in technology, medicine, and social causes, Islam has always honored women's contributions to
                  society.
                </p>
                <p>
                  Our platform celebrates these achievements while providing resources that align with Islamic values of
                  modesty, respect, and empowerment.
                </p>
              </div>
              <div className="mt-6 p-4 bg-green-50 rounded-lg border-l-4 border-green-500">
                <p className="text-green-800 font-medium">
                  "Paradise lies at the feet of your mother." - Prophet Muhammad (PBUH)
                </p>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="Lebanese women in traditional and modern roles"
                width={600}
                height={500}
                className="rounded-lg shadow-lg"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold text-red-600">75%</div>
                  <div className="text-sm text-gray-600">Lebanese women in higher education</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
