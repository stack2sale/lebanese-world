import Link from "next/link"
import { Heart, Mail, Phone, MapPin, Instagram, Youtube, Facebook } from "lucide-react"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  const footerLinks = {
    discover: [
      { name: "Cultural Heritage", href: "/discover/heritage" },
      { name: "Islamic Values", href: "/discover/islamic-values" },
      { name: "Lebanese Diaspora", href: "/discover/diaspora" },
      { name: "Traditional Arts", href: "/discover/arts" },
      { name: "Hidden Gems", href: "/discover/hidden-gems" },
    ],
    marketplace: [
      { name: "Digital Products", href: "/marketplace/digital" },
      { name: "Physical Crafts", href: "/marketplace/physical" },
      { name: "Experiences", href: "/marketplace/experiences" },
      { name: "Custom Requests", href: "/marketplace/custom" },
      { name: "Gift Cards", href: "/marketplace/gift-cards" },
    ],
    travel: [
      { name: "Halal Tours", href: "/tours" },
      { name: "Hotels & Stays", href: "/travel/hotels" },
      { name: "Flight Deals", href: "/travel/flights" },
      { name: "Travel Packages", href: "/travel/packages" },
      { name: "Travel Guide", href: "/travel/guide" },
    ],
    support: [
      { name: "Contact Us", href: "/contact" },
      { name: "FAQ", href: "/faq" },
      { name: "Shipping Info", href: "/shipping" },
      { name: "Returns", href: "/returns" },
      { name: "Privacy Policy", href: "/privacy" },
    ],
  }

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-green-600 rounded-lg flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="font-playfair text-xl font-bold">Lebanese World</span>
                <span className="block text-sm text-gray-400 -mt-1">Official</span>
              </div>
            </Link>

            <p className="text-gray-300 mb-6 leading-relaxed">
              Celebrating Lebanese culture and Islamic values worldwide. Connecting the diaspora through authentic
              experiences, products, and stories that honor our rich heritage.
            </p>

            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center">
                <Mail className="w-4 h-4 mr-3 text-gray-400" />
                <span className="text-gray-300">hello@lebaneseworldofficial.com</span>
              </div>
              <div className="flex items-center">
                <Phone className="w-4 h-4 mr-3 text-gray-400" />
                <span className="text-gray-300">+961-XX-XXXXXX</span>
              </div>
              <div className="flex items-center">
                <MapPin className="w-4 h-4 mr-3 text-gray-400" />
                <span className="text-gray-300">Beirut, Lebanon & Worldwide</span>
              </div>
            </div>
          </div>

          {/* Discover Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Discover</h3>
            <ul className="space-y-2">
              {footerLinks.discover.map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-gray-300 hover:text-white transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Marketplace Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Marketplace</h3>
            <ul className="space-y-2">
              {footerLinks.marketplace.map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-gray-300 hover:text-white transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Travel & Support */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Travel & Support</h3>
            <ul className="space-y-2">
              {footerLinks.travel.slice(0, 3).map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-gray-300 hover:text-white transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
              {footerLinks.support.slice(0, 2).map((link) => (
                <li key={link.name}>
                  <Link href={link.href} className="text-gray-300 hover:text-white transition-colors">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Islamic Values Section */}
        <div className="mt-12 pt-8 border-t border-gray-800">
          <div className="text-center">
            <h3 className="font-playfair text-2xl font-bold mb-4">Our Islamic Values</h3>
            <p className="text-gray-300 max-w-3xl mx-auto leading-relaxed">
              We operate with the principles of honesty, compassion, and justice as taught in Islam. Our platform
              celebrates the beauty of Lebanese culture while upholding Islamic values of respect, community, and
              service to humanity.
            </p>
            <div className="mt-4 text-center">
              <p className="text-gray-400 font-amiri text-lg">"وَجَعَلْنَا مِنْهُمْ أَئِمَّةً يَهْدُونَ بِأَمْرِنَا لَمَّا صَبَرُوا"</p>
              <p className="text-gray-500 text-sm mt-1">
                "And We made from them leaders guiding by Our command when they were patient" - Quran 32:24
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              © {currentYear} Lebanese World Official. All rights reserved. Made with ❤️ for the Lebanese diaspora.
            </div>

            {/* Social Links */}
            <div className="flex space-x-4">
              <Link
                href="https://instagram.com/lebaneseworldofficial"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </Link>
              <Link
                href="https://youtube.com/lebaneseworldofficial"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Youtube className="w-5 h-5" />
              </Link>
              <Link
                href="https://facebook.com/lebaneseworldofficial"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Facebook className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
