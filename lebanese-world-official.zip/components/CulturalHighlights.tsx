"use client"

import { useState } from "react"
import Image from "next/image"
import { MapPin, Clock, Users, Star } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function CulturalHighlights() {
  const [activeCategory, setActiveCategory] = useState("all")

  const categories = [
    { id: "all", name: "All Highlights" },
    { id: "heritage", name: "Heritage Sites" },
    { id: "food", name: "Culinary Culture" },
    { id: "arts", name: "Arts & Crafts" },
    { id: "festivals", name: "Festivals" },
  ]

  const highlights = [
    {
      id: 1,
      category: "heritage",
      title: "Baalbek Temple Complex",
      description: "Ancient Roman ruins showcasing Lebanon's rich historical tapestry",
      image: "/placeholder.svg?height=300&width=400",
      location: "Baalbek, Bekaa Valley",
      duration: "3-4 hours",
      visitors: "2.5K monthly",
      rating: 4.9,
      tags: ["Historical", "UNESCO", "Ancient"],
      isHalal: true,
    },
    {
      id: 2,
      category: "food",
      title: "Traditional Lebanese Mezze",
      description: "Discover the art of Lebanese hospitality through authentic mezze culture",
      image: "/placeholder.svg?height=300&width=400",
      location: "Nationwide",
      duration: "2-3 hours",
      visitors: "5K monthly",
      rating: 4.8,
      tags: ["Halal", "Traditional", "Family"],
      isHalal: true,
    },
    {
      id: 3,
      category: "arts",
      title: "Phoenician Glass Blowing",
      description: "Ancient craft techniques passed down through generations",
      image: "/placeholder.svg?height=300&width=400",
      location: "Sarafand, South Lebanon",
      duration: "2 hours",
      visitors: "1.2K monthly",
      rating: 4.7,
      tags: ["Artisan", "Traditional", "Hands-on"],
      isHalal: true,
    },
    {
      id: 4,
      category: "heritage",
      title: "Cedars of God",
      description: "Sacred cedar trees mentioned in religious texts",
      image: "/placeholder.svg?height=300&width=400",
      location: "Bsharri, North Lebanon",
      duration: "4-5 hours",
      visitors: "3K monthly",
      rating: 4.9,
      tags: ["Nature", "Sacred", "UNESCO"],
      isHalal: true,
    },
    {
      id: 5,
      category: "festivals",
      title: "Ramadan Traditions",
      description: "Experience Lebanese Ramadan customs and community spirit",
      image: "/placeholder.svg?height=300&width=400",
      location: "Various Cities",
      duration: "Full month",
      visitors: "10K monthly",
      rating: 5.0,
      tags: ["Islamic", "Community", "Spiritual"],
      isHalal: true,
    },
    {
      id: 6,
      category: "food",
      title: "Halal Lebanese Sweets",
      description: "Traditional desserts made with halal ingredients and love",
      image: "/placeholder.svg?height=300&width=400",
      location: "Tripoli, North Lebanon",
      duration: "1-2 hours",
      visitors: "4K monthly",
      rating: 4.8,
      tags: ["Halal", "Sweets", "Traditional"],
      isHalal: true,
    },
  ]

  const filteredHighlights =
    activeCategory === "all" ? highlights : highlights.filter((item) => item.category === activeCategory)

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Cultural Highlights</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Immerse yourself in authentic Lebanese experiences that celebrate our heritage, traditions, and Islamic
            values through carefully curated cultural journeys.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={activeCategory === category.id ? "default" : "outline"}
              onClick={() => setActiveCategory(category.id)}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                activeCategory === category.id
                  ? "bg-gradient-to-r from-red-600 to-green-600 text-white"
                  : "hover:bg-gray-50"
              }`}
            >
              {category.name}
            </Button>
          ))}
        </div>

        {/* Highlights Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredHighlights.map((highlight) => (
            <Card
              key={highlight.id}
              className="group overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="relative overflow-hidden">
                <Image
                  src={highlight.image || "/placeholder.svg"}
                  alt={highlight.title}
                  width={400}
                  height={300}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 flex gap-2">
                  {highlight.isHalal && <Badge className="bg-green-500 text-white">Halal Certified</Badge>}
                  <Badge variant="secondary" className="bg-white/90 text-gray-700">
                    {highlight.category}
                  </Badge>
                </div>
                <div className="absolute top-4 right-4 bg-white/90 rounded-full p-2">
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{highlight.rating}</span>
                  </div>
                </div>
              </div>

              <CardContent className="p-6">
                <h3 className="font-playfair text-xl font-bold text-gray-900 mb-2 group-hover:text-red-600 transition-colors">
                  {highlight.title}
                </h3>
                <p className="text-gray-600 mb-4 leading-relaxed">{highlight.description}</p>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm text-gray-500">
                    <MapPin className="w-4 h-4 mr-2" />
                    {highlight.location}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="w-4 h-4 mr-2" />
                    {highlight.duration}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Users className="w-4 h-4 mr-2" />
                    {highlight.visitors} visitors
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {highlight.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <Button className="w-full bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700">
                  Explore More
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <Button size="lg" variant="outline" className="px-8 py-4 text-lg">
            View All Cultural Experiences
          </Button>
        </div>
      </div>
    </section>
  )
}
