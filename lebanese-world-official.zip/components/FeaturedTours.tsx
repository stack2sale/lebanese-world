"use client"

import { useState } from "react"
import Image from "next/image"
import { MapPin, Clock, Users, Star, Calendar, Phone } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function FeaturedTours() {
  const [activeFilter, setActiveFilter] = useState("all")

  const filters = [
    { id: "all", name: "All Tours" },
    { id: "religious", name: "Religious Sites" },
    { id: "cultural", name: "Cultural Heritage" },
    { id: "nature", name: "Nature & Hiking" },
    { id: "food", name: "Food Tours" },
  ]

  const tours = [
    {
      id: 1,
      title: "Sacred Sites of Lebanon",
      description: "Visit historic mosques, churches, and religious landmarks with expert guides",
      image: "/placeholder.svg?height=300&width=400",
      price: 89,
      duration: "Full Day",
      groupSize: "8-12 people",
      rating: 4.9,
      reviews: 156,
      location: "Beirut & Surroundings",
      category: "religious",
      highlights: ["Al-Omari Mosque", "Mohammad Al-Amin Mosque", "Religious History"],
      isHalalFriendly: true,
      nextAvailable: "2024-02-15",
      whatsappBooking: "+961-XX-XXXXXX",
    },
    {
      id: 2,
      title: "Beirut Cultural Walking Tour",
      description: "Explore downtown Beirut's rich history, architecture, and cultural landmarks",
      image: "/placeholder.svg?height=300&width=400",
      price: 45,
      duration: "4 hours",
      groupSize: "6-15 people",
      rating: 4.8,
      reviews: 203,
      location: "Downtown Beirut",
      category: "cultural",
      highlights: ["Martyrs Square", "Grand Serail", "Traditional Souks"],
      isHalalFriendly: true,
      nextAvailable: "2024-02-12",
      whatsappBooking: "+961-XX-XXXXXX",
    },
    {
      id: 3,
      title: "Cedars & Qadisha Valley Hike",
      description: "Discover Lebanon's natural beauty and UNESCO World Heritage sites",
      image: "/placeholder.svg?height=300&width=400",
      price: 75,
      duration: "8 hours",
      groupSize: "4-10 people",
      rating: 4.9,
      reviews: 89,
      location: "North Lebanon",
      category: "nature",
      highlights: ["Cedars of God", "Qadisha Valley", "Mountain Villages"],
      isHalalFriendly: true,
      nextAvailable: "2024-02-18",
      whatsappBooking: "+961-XX-XXXXXX",
    },
    {
      id: 4,
      title: "Halal Food Discovery Tour",
      description: "Taste authentic Lebanese cuisine at certified halal restaurants and markets",
      image: "/placeholder.svg?height=300&width=400",
      price: 65,
      duration: "5 hours",
      groupSize: "6-12 people",
      rating: 4.8,
      reviews: 234,
      location: "Beirut & Tripoli",
      category: "food",
      highlights: ["Traditional Mezze", "Halal Sweets", "Spice Markets"],
      isHalalFriendly: true,
      nextAvailable: "2024-02-14",
      whatsappBooking: "+961-XX-XXXXXX",
    },
    {
      id: 5,
      title: "Baalbek Temple Complex",
      description: "Explore ancient Roman ruins and learn about Lebanon's historical significance",
      image: "/placeholder.svg?height=300&width=400",
      price: 95,
      duration: "6 hours",
      groupSize: "8-16 people",
      rating: 4.9,
      reviews: 167,
      location: "Bekaa Valley",
      category: "cultural",
      highlights: ["Temple of Jupiter", "Temple of Bacchus", "Archaeological Museum"],
      isHalalFriendly: true,
      nextAvailable: "2024-02-16",
      whatsappBooking: "+961-XX-XXXXXX",
    },
    {
      id: 6,
      title: "Tyre & Sidon Heritage Tour",
      description: "Discover Phoenician history and coastal beauty in southern Lebanon",
      image: "/placeholder.svg?height=300&width=400",
      price: 80,
      duration: "7 hours",
      groupSize: "6-14 people",
      rating: 4.7,
      reviews: 98,
      location: "South Lebanon",
      category: "cultural",
      highlights: ["Tyre Hippodrome", "Sidon Sea Castle", "Phoenician Ruins"],
      isHalalFriendly: true,
      nextAvailable: "2024-02-20",
      whatsappBooking: "+961-XX-XXXXXX",
    },
  ]

  const filteredTours = activeFilter === "all" ? tours : tours.filter((tour) => tour.category === activeFilter)

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Halal-Friendly Tours & Experiences
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Discover Lebanon through carefully curated tours that respect Islamic values while showcasing our rich
            cultural heritage and natural beauty.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {filters.map((filter) => (
            <Button
              key={filter.id}
              variant={activeFilter === filter.id ? "default" : "outline"}
              onClick={() => setActiveFilter(filter.id)}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                activeFilter === filter.id
                  ? "bg-gradient-to-r from-red-600 to-green-600 text-white"
                  : "hover:bg-gray-50"
              }`}
            >
              {filter.name}
            </Button>
          ))}
        </div>

        {/* Tours Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTours.map((tour) => (
            <Card
              key={tour.id}
              className="group overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="relative overflow-hidden">
                <Image
                  src={tour.image || "/placeholder.svg"}
                  alt={tour.title}
                  width={400}
                  height={300}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />

                {/* Badges */}
                <div className="absolute top-4 left-4 flex flex-col gap-2">
                  {tour.isHalalFriendly && <Badge className="bg-green-500 text-white">Halal Friendly</Badge>}
                  <Badge variant="secondary" className="bg-white/90 text-gray-700 capitalize">
                    {tour.category}
                  </Badge>
                </div>

                {/* Rating */}
                <div className="absolute top-4 right-4 bg-white/90 rounded-full px-2 py-1">
                  <div className="flex items-center space-x-1">
                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    <span className="text-xs font-medium">{tour.rating}</span>
                  </div>
                </div>

                {/* Price */}
                <div className="absolute bottom-4 right-4 bg-white/90 rounded-lg px-3 py-1">
                  <span className="text-lg font-bold text-gray-900">${tour.price}</span>
                </div>
              </div>

              <CardContent className="p-6">
                <h3 className="font-playfair text-xl font-bold text-gray-900 mb-2 group-hover:text-red-600 transition-colors">
                  {tour.title}
                </h3>

                <p className="text-gray-600 mb-4 leading-relaxed">{tour.description}</p>

                {/* Tour Details */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm text-gray-500">
                    <MapPin className="w-4 h-4 mr-2" />
                    {tour.location}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="w-4 h-4 mr-2" />
                    {tour.duration}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Users className="w-4 h-4 mr-2" />
                    {tour.groupSize}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="w-4 h-4 mr-2" />
                    Next: {new Date(tour.nextAvailable).toLocaleDateString()}
                  </div>
                </div>

                {/* Highlights */}
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-gray-900 mb-2">Tour Highlights:</h4>
                  <div className="flex flex-wrap gap-1">
                    {tour.highlights.map((highlight, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {highlight}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Reviews */}
                <div className="flex items-center text-sm text-gray-500 mb-4">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                  <span>
                    {tour.rating} ({tour.reviews} reviews)
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2">
                  <Button className="w-full bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700">
                    Book Now
                  </Button>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <MapPin className="w-4 h-4 mr-1" />
                      View Map
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <Phone className="w-4 h-4 mr-1" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-red-50 to-green-50 rounded-2xl p-8 lg:p-12">
            <h3 className="font-playfair text-3xl font-bold text-gray-900 mb-4">Can't Find What You're Looking For?</h3>
            <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto">
              We offer custom tours tailored to your interests, group size, and Islamic requirements. Contact us to
              create your perfect Lebanese experience.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700"
              >
                Request Custom Tour
              </Button>
              <Button size="lg" variant="outline">
                View All Tours
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
