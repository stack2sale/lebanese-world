"use client"

import { useState, useEffect } from "react"
import { Quote } from "lucide-react"

export default function AnimatedQuotes() {
  const [currentQuote, setCurrentQuote] = useState(0)

  const quotes = [
    {
      text: "Lebanon is not a country, it is a message of freedom and an example of pluralism for East and West.",
      author: "Pope John Paul II",
      category: "Heritage",
    },
    {
      text: "The best of people are those who benefit others.",
      author: "Prophet Muhammad (PBUH)",
      category: "Islamic Wisdom",
      arabic: "خير الناس أنفعهم للناس",
    },
    {
      text: "We are not makers of history. We are made by history.",
      author: "Khalil Gibran",
      category: "Lebanese Poet",
    },
    {
      text: "And whoever saves a life, it is as if he has saved all of mankind.",
      author: "Quran 5:32",
      category: "Islamic Values",
      arabic: "وَمَنْ أَحْيَاهَا فَكَأَنَّمَا أَحْيَا النَّاسَ جَمِيعًا",
    },
    {
      text: "Lebanon will always be the crossroads of civilizations.",
      author: "Fairuz",
      category: "Lebanese Icon",
    },
    {
      text: "Seek knowledge from the cradle to the grave.",
      author: "Prophet Muhammad (PBUH)",
      category: "Islamic Wisdom",
      arabic: "اطلبوا العلم من المهد إلى اللحد",
    },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentQuote((prev) => (prev + 1) % quotes.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [quotes.length])

  return (
    <section className="py-20 bg-gradient-to-r from-red-900 via-green-900 to-blue-900 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=100&width=100')] bg-repeat opacity-20"></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center">
          {/* Quote Icon */}
          <div className="flex justify-center mb-8">
            <div className="bg-white/10 rounded-full p-4">
              <Quote className="w-8 h-8 text-white" />
            </div>
          </div>

          {/* Quote Content */}
          <div className="min-h-[200px] flex items-center justify-center">
            <div key={currentQuote} className="animate-fade-in">
              <blockquote className="text-2xl md:text-3xl lg:text-4xl font-playfair text-white leading-relaxed mb-6">
                "{quotes[currentQuote].text}"
              </blockquote>

              {quotes[currentQuote].arabic && (
                <p className="text-xl md:text-2xl font-amiri text-white/90 mb-4 text-right">
                  {quotes[currentQuote].arabic}
                </p>
              )}

              <div className="text-center">
                <cite className="text-lg md:text-xl text-white/90 not-italic font-medium">
                  — {quotes[currentQuote].author}
                </cite>
                <p className="text-sm text-white/70 mt-2">{quotes[currentQuote].category}</p>
              </div>
            </div>
          </div>

          {/* Quote Indicators */}
          <div className="flex justify-center space-x-2 mt-8">
            {quotes.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentQuote(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentQuote ? "bg-white scale-125" : "bg-white/30"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
