"use client"

import { useState } from "react"
import { Instagram, Youtube, Facebook, MessageCircle, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function SocialIcons() {
  const [isExpanded, setIsExpanded] = useState(false)

  const socialLinks = [
    {
      name: "Instagram",
      icon: Instagram,
      url: "https://instagram.com/lebaneseworldofficial",
      color: "bg-pink-600 hover:bg-pink-700",
    },
    {
      name: "YouTube",
      icon: Youtube,
      url: "https://youtube.com/lebaneseworldofficial",
      color: "bg-red-600 hover:bg-red-700",
    },
    {
      name: "Facebook",
      icon: Facebook,
      url: "https://facebook.com/lebaneseworldofficial",
      color: "bg-blue-600 hover:bg-blue-700",
    },
    {
      name: "WhatsApp",
      icon: MessageCircle,
      url: "https://wa.me/961XXXXXXXX",
      color: "bg-green-600 hover:bg-green-700",
    },
  ]

  return (
    <div className="fixed right-6 bottom-6 z-50">
      <div className="flex flex-col items-end space-y-3">
        {/* Social Links */}
        <div
          className={`flex flex-col space-y-2 transition-all duration-300 ${
            isExpanded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"
          }`}
        >
          {socialLinks.map((social) => {
            const IconComponent = social.icon
            return (
              <Button
                key={social.name}
                size="sm"
                className={`w-12 h-12 rounded-full shadow-lg ${social.color} text-white transition-all duration-200 hover:scale-110`}
                onClick={() => window.open(social.url, "_blank")}
              >
                <IconComponent className="w-5 h-5" />
                <span className="sr-only">{social.name}</span>
              </Button>
            )
          })}
        </div>

        {/* Toggle Button */}
        <Button
          size="sm"
          className="w-14 h-14 rounded-full shadow-lg bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700 text-white transition-all duration-200 hover:scale-110"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <Share2 className={`w-6 h-6 transition-transform duration-200 ${isExpanded ? "rotate-45" : ""}`} />
          <span className="sr-only">Toggle social menu</span>
        </Button>
      </div>
    </div>
  )
}
