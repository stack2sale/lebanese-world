"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Play, ArrowRight, Star } from "lucide-react"

export default function Hero() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const slides = [
    {
      image: "/placeholder.svg?height=800&width=1200",
      title: "Discover the Heart of Lebanon",
      subtitle: "Where Ancient Traditions Meet Modern Islamic Values",
      description:
        "Experience authentic Lebanese culture through our curated tours, products, and stories that celebrate our rich heritage and Islamic principles.",
      cta: "Start Your Journey",
      secondaryCta: "Watch Our Story",
    },
    {
      image: "/placeholder.svg?height=800&width=1200",
      title: "Authentic Lebanese Marketplace",
      subtitle: "Halal-Certified Products & Digital Treasures",
      description:
        "Shop unique Lebanese crafts, digital guides, and cultural artifacts that bring the beauty of Lebanon to your doorstep.",
      cta: "Shop Now",
      secondaryCta: "Browse Categories",
    },
    {
      image: "/placeholder.svg?height=800&width=1200",
      title: "Cultural Tours & Experiences",
      subtitle: "Halal-Friendly Adventures Await",
      description:
        "Join our guided tours to sacred sites, traditional villages, and hidden gems that showcase Lebanon's Islamic heritage.",
      cta: "Book Tour",
      secondaryCta: "View All Tours",
    },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 6000)
    return () => clearInterval(timer)
  }, [slides.length])

  return (
    <section className="relative h-screen overflow-hidden">
      {/* Background Slides */}
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          <Image
            src={slide.image || "/placeholder.svg"}
            alt={slide.title}
            fill
            className="object-cover"
            priority={index === 0}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent" />
        </div>
      ))}

      {/* Content */}
      <div className="relative z-10 h-full flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            {/* Badge */}
            <div className="flex items-center space-x-2 mb-6">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <span className="text-white/90 text-sm">Trusted by 50K+ Lebanese worldwide</span>
            </div>

            {/* Main Content */}
            <h1 className="font-playfair text-4xl sm:text-5xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              {slides[currentSlide].title}
            </h1>

            <h2 className="text-xl sm:text-2xl lg:text-3xl text-red-400 mb-6 font-medium">
              {slides[currentSlide].subtitle}
            </h2>

            <p className="text-lg sm:text-xl text-white/90 mb-8 leading-relaxed max-w-2xl">
              {slides[currentSlide].description}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700 text-white px-8 py-4 text-lg font-semibold"
              >
                {slides[currentSlide].cta}
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-gray-900 px-8 py-4 text-lg"
              >
                <Play className="mr-2 w-5 h-5" />
                {slides[currentSlide].secondaryCta}
              </Button>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 mt-12 pt-8 border-t border-white/20">
              <div>
                <div className="text-2xl font-bold text-white">50K+</div>
                <div className="text-white/70">Community Members</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-white">1000+</div>
                <div className="text-white/70">Cultural Products</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-white">200+</div>
                <div className="text-white/70">Tours & Experiences</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-white">25+</div>
                <div className="text-white/70">Countries Served</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide ? "bg-white scale-125" : "bg-white/50"
            }`}
          />
        ))}
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 right-8 animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  )
}
