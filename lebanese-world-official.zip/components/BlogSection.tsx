"use client"

import { useState } from "react"
import Image from "next/image"
import { Calendar, User, ArrowRight, Heart, MessageCircle, Share2 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function BlogSection() {
  const [hoveredPost, setHoveredPost] = useState<number | null>(null)

  const featuredPost = {
    id: 1,
    title: "The Beauty of Lebanese Women in Islam: Breaking Stereotypes",
    excerpt:
      "Exploring how Lebanese Muslim women embody strength, intelligence, and grace while maintaining their Islamic values and cultural identity.",
    image: "/placeholder.svg?height=400&width=600",
    author: "Fatima Al-Zahra",
    date: "2024-02-10",
    readTime: "8 min read",
    category: "Islamic Values",
    tags: ["Women in Islam", "Lebanese Culture", "Empowerment"],
    likes: 234,
    comments: 45,
  }

  const blogPosts = [
    {
      id: 2,
      title: "Ramadan Traditions in Lebanese Families",
      excerpt:
        "How Lebanese families around the world celebrate the holy month with unique traditions that blend Islamic practices with cultural heritage.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Ahmad Khalil",
      date: "2024-02-08",
      readTime: "6 min read",
      category: "Traditions",
      tags: ["Ramadan", "Family", "Traditions"],
      likes: 189,
      comments: 32,
    },
    {
      id: 3,
      title: "Lebanese Diaspora Success Stories",
      excerpt:
        "Inspiring stories of Lebanese Muslims who have made significant contributions to their adopted countries while preserving their heritage.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Omar Mansour",
      date: "2024-02-06",
      readTime: "10 min read",
      category: "Diaspora",
      tags: ["Success Stories", "Diaspora", "Inspiration"],
      likes: 156,
      comments: 28,
    },
    {
      id: 4,
      title: "The Art of Lebanese Hospitality",
      excerpt:
        "Understanding how Islamic principles of generosity and kindness are woven into the fabric of Lebanese hospitality traditions.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Layla Hassan",
      date: "2024-02-04",
      readTime: "5 min read",
      category: "Culture",
      tags: ["Hospitality", "Islamic Values", "Culture"],
      likes: 203,
      comments: 41,
    },
    {
      id: 5,
      title: "Preserving Arabic Language in the Diaspora",
      excerpt:
        "Practical tips and resources for Lebanese families to maintain their Arabic language skills across generations.",
      image: "/placeholder.svg?height=300&width=400",
      author: "Dr. Yusuf Karam",
      date: "2024-02-02",
      readTime: "7 min read",
      category: "Language",
      tags: ["Arabic", "Education", "Heritage"],
      likes: 178,
      comments: 35,
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl lg:text-5xl font-bold text-gray-900 mb-6">Stories & Insights</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Discover inspiring stories, cultural insights, and Islamic perspectives that celebrate Lebanese heritage and
            connect our global community.
          </p>
        </div>

        {/* Featured Post */}
        <div className="mb-16">
          <Card className="overflow-hidden shadow-2xl hover:shadow-3xl transition-all duration-500 transform hover:-translate-y-1">
            <div className="grid lg:grid-cols-2 gap-0">
              <div className="relative h-64 lg:h-auto">
                <Image
                  src={featuredPost.image || "/placeholder.svg"}
                  alt={featuredPost.title}
                  fill
                  className="object-cover"
                />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-red-600 text-white">Featured Story</Badge>
                </div>
              </div>
              <CardContent className="p-8 lg:p-12 flex flex-col justify-center">
                <div className="mb-4">
                  <Badge variant="outline" className="mb-2">
                    {featuredPost.category}
                  </Badge>
                  <div className="flex flex-wrap gap-2">
                    {featuredPost.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>

                <h3 className="font-playfair text-2xl lg:text-3xl font-bold text-gray-900 mb-4 leading-tight">
                  {featuredPost.title}
                </h3>

                <p className="text-gray-600 mb-6 leading-relaxed text-lg">{featuredPost.excerpt}</p>

                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center">
                      <User className="w-4 h-4 mr-1" />
                      {featuredPost.author}
                    </div>
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      {new Date(featuredPost.date).toLocaleDateString()}
                    </div>
                    <span>{featuredPost.readTime}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center">
                      <Heart className="w-4 h-4 mr-1" />
                      {featuredPost.likes}
                    </div>
                    <div className="flex items-center">
                      <MessageCircle className="w-4 h-4 mr-1" />
                      {featuredPost.comments}
                    </div>
                  </div>

                  <Button className="bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700">
                    Read Full Story
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </div>
          </Card>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {blogPosts.map((post) => (
            <Card
              key={post.id}
              className="group overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              onMouseEnter={() => setHoveredPost(post.id)}
              onMouseLeave={() => setHoveredPost(null)}
            >
              <div className="relative overflow-hidden">
                <Image
                  src={post.image || "/placeholder.svg"}
                  alt={post.title}
                  width={400}
                  height={300}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />

                <div className="absolute top-4 left-4">
                  <Badge variant="secondary" className="bg-white/90 text-gray-700">
                    {post.category}
                  </Badge>
                </div>

                {/* Hover overlay */}
                <div
                  className={`absolute inset-0 bg-black/60 transition-opacity duration-300 flex items-center justify-center ${
                    hoveredPost === post.id ? "opacity-100" : "opacity-0"
                  }`}
                >
                  <Button variant="secondary" size="sm">
                    Read More
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </div>

              <CardContent className="p-6">
                <div className="mb-3">
                  <div className="flex flex-wrap gap-1">
                    {post.tags.slice(0, 2).map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>

                <h3 className="font-playfair text-lg font-bold text-gray-900 mb-3 group-hover:text-red-600 transition-colors line-clamp-2">
                  {post.title}
                </h3>

                <p className="text-gray-600 text-sm mb-4 leading-relaxed line-clamp-3">{post.excerpt}</p>

                <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                  <div className="flex items-center">
                    <User className="w-3 h-3 mr-1" />
                    {post.author}
                  </div>
                  <span>{post.readTime}</span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 text-xs text-gray-500">
                    <div className="flex items-center">
                      <Heart className="w-3 h-3 mr-1" />
                      {post.likes}
                    </div>
                    <div className="flex items-center">
                      <MessageCircle className="w-3 h-3 mr-1" />
                      {post.comments}
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h3 className="font-playfair text-2xl font-bold text-gray-900 mb-4">Share Your Lebanese Story</h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Have an inspiring story about Lebanese culture, Islamic values, or diaspora experiences? We'd love to
              feature your voice in our community.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700">
                Submit Your Story
              </Button>
              <Button variant="outline">View All Posts</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
