"use client"

import { useState } from "react"
import Image from "next/image"
import { Instagram, Heart, MessageCircle, ExternalLink } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function InstagramFeed() {
  const [hoveredPost, setHoveredPost] = useState<number | null>(null)

  // Mock Instagram posts - In real implementation, you'd fetch from Instagram API
  const instagramPosts = [
    {
      id: 1,
      image: "/placeholder.svg?height=300&width=300",
      caption: "Beautiful sunset over Beirut's corniche 🌅 #LebanonBeauty #Beirut",
      likes: 1234,
      comments: 89,
      timestamp: "2 hours ago",
      url: "https://instagram.com/p/example1",
    },
    {
      id: 2,
      image: "/placeholder.svg?height=300&width=300",
      caption: "Traditional Lebanese mezze spread 🥙 #LebaneseCuisine #HalalFood",
      likes: 2156,
      comments: 156,
      timestamp: "5 hours ago",
      url: "https://instagram.com/p/example2",
    },
    {
      id: 3,
      image: "/placeholder.svg?height=300&width=300",
      caption: "Cedars of God - Lebanon's natural treasure 🌲 #CedarsOfGod #Nature",
      likes: 987,
      comments: 67,
      timestamp: "1 day ago",
      url: "https://instagram.com/p/example3",
    },
    {
      id: 4,
      image: "/placeholder.svg?height=300&width=300",
      caption: "Islamic calligraphy workshop in progress ✍️ #ArabicCalligraphy #Art",
      likes: 1567,
      comments: 123,
      timestamp: "2 days ago",
      url: "https://instagram.com/p/example4",
    },
    {
      id: 5,
      image: "/placeholder.svg?height=300&width=300",
      caption: "Ramadan iftar preparation 🌙 #Ramadan #Community #Lebanon",
      likes: 3245,
      comments: 234,
      timestamp: "3 days ago",
      url: "https://instagram.com/p/example5",
    },
    {
      id: 6,
      image: "/placeholder.svg?height=300&width=300",
      caption: "Traditional Lebanese dabke dance 💃 #Dabke #Culture #Heritage",
      likes: 1876,
      comments: 98,
      timestamp: "4 days ago",
      url: "https://instagram.com/p/example6",
    },
    {
      id: 7,
      image: "/placeholder.svg?height=300&width=300",
      caption: "Baalbek temple at golden hour ✨ #Baalbek #History #Lebanon",
      likes: 2134,
      comments: 145,
      timestamp: "5 days ago",
      url: "https://instagram.com/p/example7",
    },
    {
      id: 8,
      image: "/placeholder.svg?height=300&width=300",
      caption: "Lebanese women entrepreneurs showcase 👩‍💼 #WomenInBusiness #Lebanon",
      likes: 1654,
      comments: 187,
      timestamp: "6 days ago",
      url: "https://instagram.com/p/example8",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-pink-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <Instagram className="w-8 h-8 text-pink-600 mr-3" />
            <h2 className="font-playfair text-4xl lg:text-5xl font-bold text-gray-900">Follow Our Journey</h2>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Stay connected with our daily stories, cultural highlights, and community moments through our Instagram
            feed. Join thousands of Lebanese culture enthusiasts worldwide.
          </p>
          <Button className="mt-6 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700">
            <Instagram className="w-4 h-4 mr-2" />
            Follow @LebanesWorldOfficial
          </Button>
        </div>

        {/* Instagram Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {instagramPosts.map((post) => (
            <Card
              key={post.id}
              className="group overflow-hidden cursor-pointer hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              onMouseEnter={() => setHoveredPost(post.id)}
              onMouseLeave={() => setHoveredPost(null)}
            >
              <div className="relative aspect-square overflow-hidden">
                <Image
                  src={post.image || "/placeholder.svg"}
                  alt={post.caption}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />

                {/* Overlay on hover */}
                <div
                  className={`absolute inset-0 bg-black/60 transition-opacity duration-300 flex items-center justify-center ${
                    hoveredPost === post.id ? "opacity-100" : "opacity-0"
                  }`}
                >
                  <div className="text-white text-center space-y-2">
                    <div className="flex items-center justify-center space-x-4">
                      <div className="flex items-center">
                        <Heart className="w-5 h-5 mr-1" />
                        <span className="font-semibold">{post.likes.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center">
                        <MessageCircle className="w-5 h-5 mr-1" />
                        <span className="font-semibold">{post.comments}</span>
                      </div>
                    </div>
                    <Button size="sm" variant="secondary" className="mt-2">
                      <ExternalLink className="w-4 h-4 mr-1" />
                      View Post
                    </Button>
                  </div>
                </div>

                {/* Post info overlay */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                  <p className="text-white text-xs line-clamp-2 mb-1">{post.caption}</p>
                  <p className="text-white/70 text-xs">{post.timestamp}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h3 className="font-playfair text-2xl font-bold text-gray-900 mb-4">Share Your Lebanese Story</h3>
            <p className="text-gray-600 mb-6">
              Tag us @LebanesWorldOfficial and use #LebanesePride to be featured on our feed
            </p>
            <Button variant="outline" size="lg">
              Submit Your Photo
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
