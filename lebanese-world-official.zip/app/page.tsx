import Hero from "@/components/Hero"
import FeaturedProducts from "@/components/FeaturedProducts"
import IslamicValues from "@/components/IslamicValues"
import BlogSection from "@/components/BlogSection"
import InstagramFeed from "@/components/InstagramFeed"
import Newsletter from "@/components/Newsletter"
import AnimatedQuotes from "@/components/AnimatedQuotes"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <IslamicValues />
      <FeaturedProducts />
      <BlogSection />
      <InstagramFeed />
      <AnimatedQuotes />
      <Newsletter />
    </main>
  )
}
