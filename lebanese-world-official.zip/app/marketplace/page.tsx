"use client"

import { useState } from "react"
import Image from "next/image"
import { Search, ShoppingCart, Heart, Star, Download } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function MarketplacePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("featured")

  const categories = [
    { id: "all", name: "All Products" },
    { id: "digital", name: "Digital Products" },
    { id: "physical", name: "Physical Crafts" },
    { id: "experiences", name: "Experiences" },
    { id: "food", name: "Food & Spices" },
    { id: "art", name: "Art & Calligraphy" },
    { id: "books", name: "Books & Guides" },
  ]

  const products = [
    {
      id: 1,
      title: "Complete Lebanon Travel Guide",
      description: "Comprehensive halal travel guide with 200+ pages",
      price: 29.99,
      originalPrice: 49.99,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.9,
      reviews: 234,
      category: "digital",
      isDigital: true,
      tags: ["Halal", "Travel", "PDF"],
      bestseller: true,
    },
    {
      id: 2,
      title: "Handwoven Lebanese Keffiyeh",
      description: "Authentic keffiyeh handwoven by Lebanese artisans",
      price: 89.99,
      originalPrice: 129.99,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.9,
      reviews: 67,
      category: "physical",
      isDigital: false,
      tags: ["Handmade", "Traditional", "Authentic"],
      bestseller: false,
    },
    {
      id: 3,
      title: "Arabic Calligraphy Font Pack",
      description: "12 premium Arabic fonts inspired by Lebanese heritage",
      price: 19.99,
      originalPrice: 39.99,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.8,
      reviews: 156,
      category: "digital",
      isDigital: true,
      tags: ["Arabic", "Fonts", "Design"],
      bestseller: false,
    },
    {
      id: 4,
      title: "Lebanese Spice Collection",
      description: "Premium halal spice set with traditional Lebanese blends",
      price: 45.99,
      originalPrice: 65.99,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.8,
      reviews: 123,
      category: "food",
      isDigital: false,
      tags: ["Halal", "Spices", "Authentic"],
      bestseller: true,
    },
    {
      id: 5,
      title: "Islamic Wallpaper Collection",
      description: "50 high-resolution Islamic art wallpapers",
      price: 9.99,
      originalPrice: 19.99,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.7,
      reviews: 89,
      category: "digital",
      isDigital: true,
      tags: ["Islamic", "Wallpapers", "Art"],
      bestseller: false,
    },
    {
      id: 6,
      title: "Cedar Wood Prayer Beads",
      description: "Handcrafted tasbih made from Lebanese cedar wood",
      price: 34.99,
      originalPrice: 49.99,
      image: "/placeholder.svg?height=300&width=300",
      rating: 5.0,
      reviews: 45,
      category: "physical",
      isDigital: false,
      tags: ["Cedar", "Prayer", "Handcrafted"],
      bestseller: false,
    },
    {
      id: 7,
      title: "Virtual Cooking Class",
      description: "Learn traditional Lebanese dishes with expert chefs",
      price: 39.99,
      originalPrice: 59.99,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.9,
      reviews: 178,
      category: "experiences",
      isDigital: true,
      tags: ["Cooking", "Live", "Interactive"],
      bestseller: true,
    },
    {
      id: 8,
      title: "Lebanese Heritage Book Set",
      description: "3-book collection on Lebanese history and culture",
      price: 79.99,
      originalPrice: 119.99,
      image: "/placeholder.svg?height=300&width=300",
      rating: 4.8,
      reviews: 92,
      category: "books",
      isDigital: false,
      tags: ["History", "Culture", "Education"],
      bestseller: false,
    },
  ]

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-red-50 to-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-playfair text-4xl lg:text-6xl font-bold text-gray-900 mb-6">Lebanese Marketplace</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Discover authentic Lebanese products, digital treasures, and cultural experiences that celebrate our
              heritage and Islamic values.
            </p>
          </div>
        </div>
      </section>

      {/* Filters and Search */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="text"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Filters */}
            <div className="flex gap-4 items-center">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredProducts.map((product) => (
              <Card
                key={product.id}
                className="group overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              >
                <div className="relative overflow-hidden">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.title}
                    width={300}
                    height={300}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />

                  {/* Overlay with quick actions */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <div className="flex space-x-3">
                      <Button size="sm" variant="secondary" className="rounded-full">
                        <ShoppingCart className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="secondary" className="rounded-full">
                        <Heart className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Badges */}
                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    {product.bestseller && <Badge className="bg-red-500 text-white">Bestseller</Badge>}
                    {product.isDigital && (
                      <Badge className="bg-blue-500 text-white">
                        <Download className="w-3 h-3 mr-1" />
                        Digital
                      </Badge>
                    )}
                    <Badge className="bg-green-500 text-white">
                      {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                    </Badge>
                  </div>

                  {/* Rating */}
                  <div className="absolute top-4 right-4 bg-white/90 rounded-full px-2 py-1">
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-xs font-medium">{product.rating}</span>
                    </div>
                  </div>
                </div>

                <CardContent className="p-6">
                  <h3 className="font-playfair text-lg font-bold text-gray-900 mb-2 group-hover:text-red-600 transition-colors line-clamp-2">
                    {product.title}
                  </h3>

                  <p className="text-gray-600 text-sm mb-4 leading-relaxed line-clamp-2">{product.description}</p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 mb-4">
                    {product.tags.slice(0, 2).map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  {/* Reviews */}
                  <div className="flex items-center text-sm text-gray-500 mb-4">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                    <span>
                      {product.rating} ({product.reviews} reviews)
                    </span>
                  </div>

                  {/* Price and CTA */}
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <span className="text-xl font-bold text-gray-900">${product.price}</span>
                      <span className="text-sm text-gray-500 line-through ml-2">${product.originalPrice}</span>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-red-600 to-green-600 hover:from-red-700 hover:to-green-700">
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Add to Cart
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* No Results */}
          {filteredProducts.length === 0 && (
            <div className="text-center py-16">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">No products found</h3>
              <p className="text-gray-600 mb-6">Try adjusting your search or filter criteria</p>
              <Button
                onClick={() => {
                  setSearchTerm("")
                  setSelectedCategory("all")
                }}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
