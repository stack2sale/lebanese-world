import type React from "react"
import type { Metadata } from "next"
import { Inter, Playfair_Display, Amiri } from "next/font/google"
import "./globals.css"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import SocialIcons from "@/components/SocialIcons"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const playfair = Playfair_Display({ subsets: ["latin"], variable: "--font-playfair" })
const amiri = Amiri({ subsets: ["arabic"], weight: ["400", "700"], variable: "--font-amiri" })

export const metadata: Metadata = {
  title: "Lebanese World Official | Celebrating Lebanese Culture & Heritage",
  description:
    "Discover authentic Lebanese culture, traditions, and Islamic values. Shop unique products, book cultural tours, and connect with the Lebanese diaspora worldwide.",
  keywords:
    "Lebanese culture, Islamic values, Lebanese heritage, Middle Eastern traditions, halal travel, Lebanese diaspora",
  authors: [{ name: "Lebanese World Official" }],
  openGraph: {
    title: "Lebanese World Official | Celebrating Lebanese Culture & Heritage",
    description: "Discover authentic Lebanese culture, traditions, and Islamic values.",
    url: "https://lebanese-world-official.vercel.app",
    siteName: "Lebanese World Official",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Lebanese World Official",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Lebanese World Official",
    description: "Celebrating Lebanese culture and Islamic values worldwide",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "your-google-verification-code",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable} ${amiri.variable}`}>
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        <link rel="manifest" href="/site.webmanifest" />
      </head>
      <body className="font-inter antialiased bg-white text-gray-900">
        <Header />
        {children}
        <Footer />
        <SocialIcons />
      </body>
    </html>
  )
}
