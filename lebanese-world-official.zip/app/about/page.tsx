import Image from "next/image"
import { Heart, Users, Globe, Award, Target, Eye } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function AboutPage() {
  const values = [
    {
      icon: Heart,
      title: "Authenticity",
      description: "We celebrate genuine Lebanese culture and Islamic values without compromise.",
    },
    {
      icon: Users,
      title: "Community",
      description: "Building bridges between Lebanese people worldwide and fostering unity.",
    },
    {
      icon: Globe,
      title: "Global Impact",
      description: "Spreading Lebanese heritage and Islamic principles across all continents.",
    },
    {
      icon: Award,
      title: "Excellence",
      description: "Delivering premium quality in every product, service, and experience.",
    },
  ]

  const team = [
    {
      name: "Ahmad Khalil",
      role: "Founder & CEO",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Lebanese entrepreneur passionate about preserving our cultural heritage through digital innovation.",
    },
    {
      name: "Fatima Al-Zahra",
      role: "Cultural Director",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Islamic scholar and cultural expert ensuring authentic representation of our values.",
    },
    {
      name: "Omar Mansour",
      role: "Head of Tours",
      image: "/placeholder.svg?height=300&width=300",
      bio: "Licensed tour guide with 15+ years experience in halal-friendly Lebanese tourism.",
    },
  ]

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-red-50 to-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="font-playfair text-4xl lg:text-6xl font-bold text-gray-900 mb-6">
                About Lebanese World Official
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed mb-8">
                We are a global platform dedicated to celebrating, preserving, and sharing Lebanese culture while
                upholding Islamic values of compassion, unity, and excellence.
              </p>
              <div className="flex flex-wrap gap-4">
                <Badge className="bg-red-600 text-white px-4 py-2">50K+ Community Members</Badge>
                <Badge className="bg-green-600 text-white px-4 py-2">25+ Countries Served</Badge>
                <Badge className="bg-blue-600 text-white px-4 py-2">1000+ Products & Experiences</Badge>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="Lebanese World Official Team"
                width={600}
                height={500}
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            <Card className="p-8 border-l-4 border-red-600">
              <CardContent className="p-0">
                <div className="flex items-center mb-6">
                  <Target className="w-8 h-8 text-red-600 mr-3" />
                  <h2 className="font-playfair text-3xl font-bold text-gray-900">Our Mission</h2>
                </div>
                <p className="text-lg text-gray-600 leading-relaxed">
                  To create a global platform that authentically represents Lebanese culture while promoting Islamic
                  values of peace, justice, and community. We strive to connect the Lebanese diaspora worldwide through
                  meaningful experiences, quality products, and shared stories that honor our heritage.
                </p>
              </CardContent>
            </Card>

            <Card className="p-8 border-l-4 border-green-600">
              <CardContent className="p-0">
                <div className="flex items-center mb-6">
                  <Eye className="w-8 h-8 text-green-600 mr-3" />
                  <h2 className="font-playfair text-3xl font-bold text-gray-900">Our Vision</h2>
                </div>
                <p className="text-lg text-gray-600 leading-relaxed">
                  To become the world's leading platform for Lebanese cultural exchange, where every Lebanese person,
                  regardless of location, can access authentic experiences, connect with their roots, and contribute to
                  preserving our beautiful heritage for future generations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-4xl font-bold text-gray-900 mb-6">Our Core Values</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              These principles guide everything we do, from product curation to community building.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon
              return (
                <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow">
                  <CardContent className="p-0">
                    <div className="bg-gradient-to-br from-red-600 to-green-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="font-semibold text-xl text-gray-900 mb-3">{value.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{value.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-4xl font-bold text-gray-900 mb-6">Meet Our Team</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Passionate Lebanese professionals dedicated to sharing our culture with the world.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative h-64">
                  <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
                </div>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-xl text-gray-900 mb-1">{member.name}</h3>
                  <p className="text-red-600 font-medium mb-3">{member.role}</p>
                  <p className="text-gray-600 leading-relaxed">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Islamic Values Integration */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-playfair text-4xl font-bold text-gray-900 mb-6">Islamic Values in Our Work</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Our platform operates on Islamic principles of honesty, justice, and service to humanity. We ensure all
              our offerings align with halal standards and promote positive values.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 lg:p-12 shadow-lg">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="font-playfair text-2xl font-bold text-gray-900 mb-6">Commitment to Halal Standards</h3>
                <ul className="space-y-4 text-gray-600">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    All food products and tours are certified halal
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    Content respects Islamic values and cultural sensitivities
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    Prayer times and religious considerations in all tours
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    Support for charitable causes and community development
                  </li>
                </ul>
              </div>
              <div className="text-center">
                <div className="bg-green-100 rounded-lg p-6">
                  <p className="text-green-800 font-amiri text-xl mb-2">"إِنَّمَا الْمُؤْمِنُونَ إِخْوَةٌ"</p>
                  <p className="text-green-700 font-medium">"The believers are but brothers" - Quran 49:10</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
